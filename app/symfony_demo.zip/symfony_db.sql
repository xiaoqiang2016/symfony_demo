-- phpMyAdmin SQL Dump
-- version 4.1.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2016-06-28 09:35:23
-- 服务器版本： 5.6.21-log
-- PHP Version: 5.5.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `symfony_db`
--

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `nickname` varchar(200) DEFAULT NULL,
  `sex` varchar(20) NOT NULL DEFAULT '男',
  `email` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `myqq` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nickname`, `sex`, `email`, `phone`, `myqq`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '刘少强', '男', '1979900517@qq.com', '13585824525', '1979900'),
(2, 'liushaoqiang', '21232f297a57a5a743894a0e4a801fc3', '大范甘迪', '男', '1979@sdfs.com', '13585824525', '1979900517'),
(15, 'sdfsf', '202cb962ac59075b964b07152d234b70', 'sdfs', 'sdfds', 'sddf@sdf.cc', '13585824525', '1979900517');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
