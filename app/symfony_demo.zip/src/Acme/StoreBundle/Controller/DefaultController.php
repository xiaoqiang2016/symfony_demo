<?php

namespace Acme\StoreBundle\Controller;
use Acme\StoreBundle\Entity\Users;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class DefaultController extends Controller
{
    /**
     * 用户登录主页
     */
    public function indexAction()
    {
        return $this->render('AcmeStoreBundle:Default:index.html.twig');
    }
	/**
	*用户登录
	**/
	public function loginAction(){
		$repository = $this->getDoctrine()->getRepository('AcmeStoreBundle:Users');
		$request = $this->getRequest();
		$username = $request->get("username");
		$password = $request->get("password");
		$userMsg=array(
		    "username"=>$username,
			"password"=>md5($password)
		);
		if($username && $password){
			$isUserLogin = $repository->findOneBy($userMsg);
			if($isUserLogin){
				$session = $this->getRequest()->getSession();
				$session->set("username", $isUserLogin->getUsername());
				$session->set("id", $isUserLogin->getId());
				$ret ="200";
			}else{
				$ret ="用户名和密码错误！";
			}
		}else{
			$ret ="用户名和密码错误！";
		}
		return new Response($ret);
	}
	/**
	*用户列表
	**/
	public function listsAction(){
	    return $this->render('AcmeStoreBundle:Default:lists.html.twig');
	}
	/**
	*获取列表
	**/
	public function getListsAction(){
		$session = $this->getRequest()->getSession();
		$s_username = $session->get("username");
		if($s_username){
			$repository = $this->getDoctrine()->getRepository('AcmeStoreBundle:Users');
		     $userList = $repository->findAall();
			 //var_dump($userList);exit;
			 foreach($userList as $userList) {
				  $userData[] = array(
					 "username"=>$userList->getUsername(),
					 "nickname"=>$userList->getNickname(),
					 "sex"=>$userList->getSex(),
					 "phone"=>$userList->getPhone(),
					 "email"=>$userList->getEmail(),
					 "myqq"=>$userList->getMyqq(),
					 "button"=>'<a href="/edit/id/'.$userList->getId().'" class="easyui-linkbutton" >修改</a>
		<a href="javascript:deleteuser('.$userList->getId().')" class="easyui-linkbutton" >删除</a>'
				  );
			 }
			 //var_dump($userData);exit;
			 $ret=json_encode($userData);
		}else{
			 $ret="203";
		}
		return new Response($ret);
	}
	/**
	*添加用户页面
	**/
	public function addAction(){
		return $this->render('AcmeStoreBundle:Default:add.html.twig');
	}
	/**
	*用户添加方法
	**/
	public function adduserAction(){
		$user = new Users();
		$repository = $this->getDoctrine()->getEntityManager();
		$request = $this->getRequest();
		$user->setUsername($request->get("username"));
		$user->setPassword(md5($request->get("password")));
		$user->setNickname($request->get("nickname"));
		$user->setSex($request->get("sex"));
		$user->setEmail($request->get("email"));
		$user->setPhone($request->get("phone"));
		$user->setMyqq($request->get("myqq"));
		$repository->persist($user);
		$repository->flush();
		$isAdd = $user->getId();
		if($isAdd>0){
			$ret = "添加成功！";
		}else{
			$ret = "添加异常，请重试！";
		}
		return new Response(json_encode($ret));
	}
	/**
	*注销用户
	**/
	public function logoutAction(){
		$session = $this->getRequest()->getSession();//清除session
        $session->clear();
		$ret="1";
		return new Response(json_encode($ret));
	}
	/**
	 * 删除用户
	 */
	public function deleteuserAction(){
		$request = $this->getRequest();
		$id = $request->get("id");
		$repository = $this->getDoctrine()->getEntityManager();
		$OBJuser = $repository->getRepository('AcmeStoreBundle:Users')->find($id);
		if($OBJuser){
			$repository->remove($OBJuser);
			$repository->flush();
			$msj="删除成功！";
			return new Response(json_encode($msj));
		}else{
			$msj="删除失败！";
			return new Response(json_encode($msj));
		}
	}
	/**
	 * 修改页面
	 */
	public function editAction(){
		$request = $this->getRequest();
		$id = $request->get("id");
		$repository = $this->getDoctrine()->getRepository('AcmeStoreBundle:Users');
		$userMsg = $repository->find($id);
		return $this->render('AcmeStoreBundle:Default:edit.html.twig', array('userMessage' => $userMsg));
	}
	/**
	 * 用户修改方法
	 */
	public function edituserAction(){
		$request = $this->getRequest();
		$id = $request->get("id");
		$repository = $this->getDoctrine()->getEntityManager();
		$user = $repository->getRepository('AcmeStoreBundle:Users')->find($id);
		$user->setUsername($request->get("username"));
		$user->setNickname($request->get("nickname"));
		$user->setSex($request->get("sex"));
		$user->setEmail($request->get("email"));
		$user->setPhone($request->get("phone"));
		$user->setMyqq($request->get("myqq"));
		$repository->flush();
		$isAdd = $user->getId();
		if($isAdd>0){
			$ret = "修改成功！";
		}else{
			$ret = "修改异常，请重试！";
		}
		return new Response(json_encode($ret));
	}
}
